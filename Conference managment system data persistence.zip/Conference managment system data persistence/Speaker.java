public class Speaker {
    private String name;
    private String bio;

    // Constructor
    public Speaker(String name, String bio) {
        this.name = name;
        this.bio = bio;
    }

    // Getter for name
    public String getName() {
        return name;
    }

    // Getter for bio
    public String getBio() {
        return bio;
    }

    // Additional methods, if necessary, can be added here
}
