import java.util.ArrayList;
import java.util.List;

public class Attendee {
    private String attendeeID;
    private String name;
    private String email;
    private List<Session> schedule; // Personal schedule for the attendee

    // Constructor
    public Attendee(String name, String email, String attendeeID) {
        this.name = name;
        this.email = email;
        this.attendeeID = attendeeID;
        this.schedule = new ArrayList<>(); // Initialize schedule
    }

    // Add a session to the attendee's schedule
    public void createSchedule(Session session) {
        if (!schedule.contains(session)) {
            schedule.add(session);
            System.out.println("Session added to schedule: " + session.getSessionName());
        } else {
            System.out.println("Session already in schedule.");
        }
    }

    // Getter for attendee ID
    public String getAttendeeID() {
        return attendeeID;
    }

    // Getter for attendee name
    public String getName() {
        return name;
    }

    // Getter for attendee email
    public String getEmail() {
        return email;
    }

    // Getter for the attendee's schedule
    public List<Session> getSchedule() {
        return schedule;
    }
}
