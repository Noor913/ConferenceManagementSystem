public class Feedback {
    private String feedbackID; // Unique identifier
    private String attendeeID; // Attendee providing feedback
    private String sessionID; // Session being reviewed
    private int rating; // Numeric rating
    private String comments; // Comments or feedback

    // Constructor
    public Feedback(String feedbackID, String attendeeID, String sessionID, int rating, String comments) {
        this.feedbackID = feedbackID;
        this.attendeeID = attendeeID;
        this.sessionID = sessionID;
        this.rating = rating;
        this.comments = comments;
    }

    // Getters
    public String getFeedbackID() {
        return feedbackID;
    }

    public String getAttendeeID() {
        return attendeeID;
    }

    public String getSessionID() {
        return sessionID;
    }

    public int getRating() {
        return rating;
    }

    public String getComments() {
        return comments;
    }
}
