public class Main {
    public static void main(String[] args) {
        // Step 1: Create and populate a conference
        Conference gafAI2025 = new Conference("C001", "GAF-AI 2025", "2025-06-01", "2025-06-07");
        Session session1 = new Session("S001", "Introduction to LLMs", "2025-06-01", "10:00", "Room 101");
        gafAI2025.addSession(session1);

        Attendee attendee1 = new Attendee("Dr. Abram", "abram@example.com", "A001");
        gafAI2025.registerAttendee(attendee1);

        // Step 2: Save the conference data to a file
        gafAI2025.saveToFile("conference_data.txt");

        // Step 3: Load the conference data from the file
        System.out.println("\nLoading Conference Data...");
        Conference loadedConference = Conference.loadFromFile("conference_data.txt");

        // Step 4: Verify loaded data
        if (loadedConference != null) {
            System.out.println("\nLoaded Conference: " + loadedConference.getConferenceName());
            System.out.println("Sessions: " + loadedConference.getSessions().size());
            System.out.println("Attendees: " + loadedConference.getAttendees().size());
        }
    }
}
