import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Conference {
    private String conferenceID; // Unique identifier
    private String conferenceName;
    private String startDate;
    private String endDate;
    private List<Session> sessions; // List of sessions
    private List<Attendee> attendees; // List of attendees

    // Constructor
    public Conference(String conferenceID, String conferenceName, String startDate, String endDate) {
        this.conferenceID = conferenceID;
        this.conferenceName = conferenceName;
        this.startDate = startDate;
        this.endDate = endDate;
        this.sessions = new ArrayList<>(); // Initialize sessions
        this.attendees = new ArrayList<>(); // Initialize attendees
    }

    // Register an attendee
    public void registerAttendee(Attendee attendee) {
        if (attendee != null) {
            attendees.add(attendee);
        } else {
            System.out.println("Cannot register a null attendee.");
        }
    }

    // Add a session
    public void addSession(Session session) {
        if (session != null) {
            sessions.add(session);
        } else {
            System.out.println("Cannot add a null session.");
        }
    }

    // Generate certificates
    public void generateCertificates() {
        for (Attendee attendee : attendees) {
            System.out.println("Certificate for " + attendee.getName() + ":");
            System.out.println("Attendee ID: " + attendee.getAttendeeID());
            System.out.println("Conference: " + conferenceName);
            System.out.println("Dates: " + startDate + " to " + endDate);
            System.out.println("Thank you for attending!\n");
        }
    }

    // Save data to a text file
    public void saveToFile(String fileName) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            // Write conference details
            writer.write("Conference: " + conferenceID + ", " + conferenceName + ", " + startDate + ", " + endDate);
            writer.newLine();

            // Write session details
            for (Session session : sessions) {
                writer.write("Session: " + session.getSessionID() + ", " + session.getSessionName() + ", " +
                             session.getDate() + ", " + session.getTime() + ", " + session.getRoom());
                writer.newLine();
            }

            // Write attendee details
            for (Attendee attendee : attendees) {
                writer.write("Attendee: " + attendee.getAttendeeID() + ", " + attendee.getName() + ", " + attendee.getEmail());
                writer.newLine();
            }

            System.out.println("Conference data saved to file: " + fileName);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Load data from a text file
    public static Conference loadFromFile(String fileName) {
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            Conference conference = null;
            List<Session> sessions = new ArrayList<>();
            List<Attendee> attendees = new ArrayList<>();

            while ((line = reader.readLine()) != null) {
                if (line.startsWith("Conference:")) {
                    // Parse conference details
                    String[] parts = line.split(", ");
                    String id = parts[0].split(": ")[1];
                    String name = parts[1];
                    String startDate = parts[2];
                    String endDate = parts[3];
                    conference = new Conference(id, name, startDate, endDate);
                } else if (line.startsWith("Session:")) {
                    // Parse session details
                    String[] parts = line.split(", ");
                    String sessionID = parts[0].split(": ")[1];
                    String sessionName = parts[1];
                    String date = parts[2];
                    String time = parts[3];
                    String room = parts[4];
                    sessions.add(new Session(sessionID, sessionName, date, time, room));
                } else if (line.startsWith("Attendee:")) {
                    // Parse attendee details
                    String[] parts = line.split(", ");
                    String attendeeID = parts[0].split(": ")[1];
                    String name = parts[1];
                    String email = parts[2];
                    attendees.add(new Attendee(name, email, attendeeID));
                }
            }

            if (conference != null) {
                conference.sessions = sessions;
                conference.attendees = attendees;
            }
            return conference;

        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    // Getter methods
    public String getConferenceName() {
        return conferenceName;
    }

    public List<Session> getSessions() {
        return sessions;
    }

    public List<Attendee> getAttendees() {
        return attendees;
    }
}
