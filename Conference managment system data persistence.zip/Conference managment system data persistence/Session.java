import java.util.ArrayList;
import java.util.List;

public class Session {
    private String sessionID;
    private String sessionName;
    private String date;
    private String time;
    private String room;
    private Speaker speaker;
    private List<Attendee> attendees;

    // Constructor
    public Session(String sessionID, String sessionName, String date, String time, String room) {
        this.sessionID = sessionID;
        this.sessionName = sessionName;
        this.date = date;
        this.time = time;
        this.room = room;
        this.attendees = new ArrayList<>();
    }

    // Assign a speaker to the session
    public void assignSpeaker(Speaker speaker) {
        this.speaker = speaker;
    }

    // Add an attendee to the session
    public void addAttendee(Attendee attendee) {
        attendees.add(attendee);
    }

    // Getter methods
    public String getSessionID() {
        return sessionID;
    }

    public String getSessionName() {
        return sessionName;
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }

    public String getRoom() {
        return room;
    }

    public String getSessionDetails() {
        StringBuilder details = new StringBuilder();
        details.append("Session ID: ").append(sessionID).append("\n");
        details.append("Name: ").append(sessionName).append("\n");
        details.append("Date: ").append(date).append("\n");
        details.append("Time: ").append(time).append("\n");
        details.append("Room: ").append(room).append("\n");
        if (speaker != null) {
            details.append("Speaker: ").append(speaker.getName()).append("\n");
        } else {
            details.append("Speaker: Not assigned\n");
        }
        details.append("Attendees: ").append(attendees.size());
        return details.toString();
    }
}
