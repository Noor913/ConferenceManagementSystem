import java.util.ArrayList;
import java.util.List;

public class Attendee extends Person {
    private String attendeeID;
    private List<Session> schedule; // Personal schedule for the attendee

    // Constructor
    public Attendee(String name, String email, String attendeeID) {
        super(name, email); // Call the constructor of the Person class
        this.attendeeID = attendeeID;
        this.schedule = new ArrayList<>(); // Initialize schedule
    }

    // Add a session to the attendee's schedule
    public void createSchedule(Session session) {
        if (!schedule.contains(session)) {
            schedule.add(session);
            System.out.println("Session added to schedule: " + session.getSessionName());
        } else {
            System.out.println("Session already in schedule.");
        }
    }

    // Getter for attendee ID
    public String getAttendeeID() {
        return attendeeID;
    }

    // Getter for the attendee's schedule
    public List<Session> getSchedule() {
        return schedule;
    }
}

