public class Speaker extends Person {
    private String bio;

    // Constructor
    public Speaker(String name, String email, String bio) {
        super(name, email); // Call the constructor of the Person class
        this.bio = bio;
    }

    // Getter for bio
    public String getBio() {
        return bio;
    }
}
