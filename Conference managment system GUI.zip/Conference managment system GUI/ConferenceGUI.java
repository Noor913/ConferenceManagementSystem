import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ConferenceGUI {
    private Conference conference;

    public ConferenceGUI(Conference conference) {
        this.conference = conference;

        // Create the main frame
        JFrame frame = new JFrame("Conference Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 400);

        // Create a panel for buttons
        JPanel panel = new JPanel(new GridLayout(5, 1));
        JButton registerAttendeeButton = new JButton("Register Attendee");
        JButton addSessionButton = new JButton("Add Session");
        JButton assignSpeakerButton = new JButton("Assign Speaker");
        JButton displayDataButton = new JButton("Display Conference Data");
        JButton saveDataButton = new JButton("Save Conference Data");

        // Add action listeners
        registerAttendeeButton.addActionListener(e -> registerAttendee());
        addSessionButton.addActionListener(e -> addSession());
        assignSpeakerButton.addActionListener(e -> assignSpeaker());
        displayDataButton.addActionListener(e -> displayConferenceData());
        saveDataButton.addActionListener(e -> saveConferenceData());

        // Add buttons to the panel
        panel.add(registerAttendeeButton);
        panel.add(addSessionButton);
        panel.add(assignSpeakerButton);
        panel.add(displayDataButton);
        panel.add(saveDataButton);

        // Add panel to frame
        frame.add(panel);
        frame.setVisible(true);
    }

    private void registerAttendee() {
        JTextField nameField = new JTextField();
        JTextField emailField = new JTextField();
        JTextField idField = new JTextField();

        Object[] message = {
            "Name:", nameField,
            "Email:", emailField,
            "Attendee ID:", idField
        };

        int option = JOptionPane.showConfirmDialog(null, message, "Register Attendee", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String name = nameField.getText();
            String email = emailField.getText();
            String id = idField.getText();
            if (!name.isEmpty() && !email.isEmpty() && !id.isEmpty()) {
                conference.registerAttendee(new Attendee(name, email, id));
                JOptionPane.showMessageDialog(null, "Attendee Registered Successfully!");
            } else {
                JOptionPane.showMessageDialog(null, "All fields are required!");
            }
        }
    }

    private void addSession() {
        JTextField idField = new JTextField();
        JTextField nameField = new JTextField();
        JTextField dateField = new JTextField();
        JTextField timeField = new JTextField();
        JTextField roomField = new JTextField();

        Object[] message = {
            "Session ID:", idField,
            "Session Name:", nameField,
            "Date (YYYY-MM-DD):", dateField,
            "Time (HH:MM):", timeField,
            "Room:", roomField
        };

        int option = JOptionPane.showConfirmDialog(null, message, "Add Session", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String id = idField.getText();
            String name = nameField.getText();
            String date = dateField.getText();
            String time = timeField.getText();
            String room = roomField.getText();
            if (!id.isEmpty() && !name.isEmpty() && !date.isEmpty() && !time.isEmpty() && !room.isEmpty()) {
                Session session = new Session(id, name, date, time, room);
                conference.addSession(session);
                JOptionPane.showMessageDialog(null, "Session Added Successfully!");
            } else {
                JOptionPane.showMessageDialog(null, "All fields are required!");
            }
        }
    }

    private void assignSpeaker() {
        JTextField sessionIDField = new JTextField();
        JTextField nameField = new JTextField();
        JTextField emailField = new JTextField();
        JTextField bioField = new JTextField();

        Object[] message = {
            "Session ID:", sessionIDField,
            "Speaker Name:", nameField,
            "Speaker Email:", emailField,
            "Speaker Bio:", bioField
        };

        int option = JOptionPane.showConfirmDialog(null, message, "Assign Speaker", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String sessionID = sessionIDField.getText();
            String name = nameField.getText();
            String email = emailField.getText();
            String bio = bioField.getText();
            Session session = conference.getSessions().stream()
                .filter(s -> s.getSessionID().equals(sessionID))
                .findFirst()
                .orElse(null);

            if (session != null && !name.isEmpty() && !email.isEmpty() && !bio.isEmpty()) {
                session.assignSpeaker(new Speaker(name, email, bio));
                JOptionPane.showMessageDialog(null, "Speaker Assigned Successfully!");
            } else {
                JOptionPane.showMessageDialog(null, "Invalid Session ID or Missing Fields!");
            }
        }
    }

    private void displayConferenceData() {
        StringBuilder data = new StringBuilder();
        data.append("Conference: ").append(conference.getConferenceName()).append("\n\n");
        data.append("Sessions:\n");
        for (Session session : conference.getSessions()) {
            data.append(session.getSessionName()).append(" - ").append(session.getDate()).append("\n");
        }
        data.append("\nAttendees:\n");
        for (Attendee attendee : conference.getAttendees()) {
            data.append(attendee.getName()).append(" - ").append(attendee.getEmail()).append("\n");
        }

        JOptionPane.showMessageDialog(null, data.toString(), "Conference Data", JOptionPane.INFORMATION_MESSAGE);
    }

    private void saveConferenceData() {
        conference.saveToFile("conference_data.txt");
        JOptionPane.showMessageDialog(null, "Conference Data Saved Successfully!");
    }

    public static void main(String[] args) {
        Conference conference = new Conference("C001", "GAF-AI 2025", "2025-06-01", "2025-06-07");
        new ConferenceGUI(conference);
    }
}
