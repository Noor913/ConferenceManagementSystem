import java.util.ArrayList;
import java.util.List;

public class Session {
    private String sessionID;
    private String sessionName;
    private String date;
    private String time;
    private String room;
    private Speaker speaker; // Speaker assigned to the session
    private List<Attendee> attendeeList; // List of attendees for the session

    // Constructor
    public Session(String sessionID, String sessionName, String date, String time, String room) {
        this.sessionID = sessionID;
        this.sessionName = sessionName;
        this.date = date;
        this.time = time;
        this.room = room;
        this.attendeeList = new ArrayList<>(); // Initialize attendee list
    }

    // Assign a speaker to the session
    public void assignSpeaker(Speaker speaker) {
        this.speaker = speaker;
    }

    // Add an attendee to the session
    public void addAttendee(Attendee attendee) {
        if (attendee != null) {
            attendeeList.add(attendee);
        } else {
            System.out.println("Cannot add a null attendee.");
        }
    }

    // Get session details
    public String getSessionDetails() {
        String speakerName = (speaker != null) ? speaker.getName() : "No speaker assigned";
        return "Session ID: " + sessionID +
               "\nName: " + sessionName +
               "\nDate: " + date +
               "\nTime: " + time +
               "\nRoom: " + room +
               "\nSpeaker: " + speakerName +
               "\nAttendees: " + attendeeList.size();
    }

    // Getter for the list of attendees
    public List<Attendee> getAttendeeList() {
        return attendeeList;
    }

    // Getter methods for session properties
    public String getSessionID() {
        return sessionID;
    }

    public String getSessionName() {
        return sessionName;
    }
}
