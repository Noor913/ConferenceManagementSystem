import java.util.ArrayList;
import java.util.List;

public class Conference {
    private String conferenceID; // Unique identifier
    private String conferenceName;
    private String startDate;
    private String endDate;
    private List<Session> sessions; // List of sessions
    private List<Attendee> attendees; // List of attendees

    // Constructor
    public Conference(String conferenceID, String conferenceName, String startDate, String endDate) {
        this.conferenceID = conferenceID;
        this.conferenceName = conferenceName;
        this.startDate = startDate;
        this.endDate = endDate;
        this.sessions = new ArrayList<>(); // Initialize sessions
        this.attendees = new ArrayList<>(); // Initialize attendees
    }

    // Register an attendee
    public void registerAttendee(Attendee attendee) {
        if (attendee != null) {
            attendees.add(attendee);
        } else {
            System.out.println("Cannot register a null attendee.");
        }
    }

    // Add a session
    public void addSession(Session session) {
        if (session != null) {
            sessions.add(session);
        } else {
            System.out.println("Cannot add a null session.");
        }
    }

    // Generate certificates
    public void generateCertificates() {
        for (Attendee attendee : attendees) {
            System.out.println("Certificate for " + attendee.getName() + ":");
            System.out.println("Attendee ID: " + attendee.getAttendeeID());
            System.out.println("Conference: " + conferenceName);
            System.out.println("Dates: " + startDate + " to " + endDate);
            System.out.println("Thank you for attending!\n");
        }
    }

    // Getter methods
    public String getConferenceName() {
        return conferenceName;
    }

    public List<Session> getSessions() {
        return sessions;
    }

    public List<Attendee> getAttendees() {
        return attendees;
    }
}
