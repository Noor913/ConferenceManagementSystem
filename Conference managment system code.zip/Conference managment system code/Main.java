public class Main {
    public static void main(String[] args) {
        // Create a conference
        Conference gafAI2025 = new Conference("C001", "GAF-AI 2025", "2025-06-01", "2025-06-07");

        // Create a speaker
        Speaker speaker1 = new Speaker("Dr. John Smith", "Expert in Large Language Models");

        // Create sessions
        Session session1 = new Session("S001", "Introduction to LLMs", "2025-06-01", "10:00", "Room 101");

        // Assign a speaker
        session1.assignSpeaker(speaker1);

        // Add session to the conference
        gafAI2025.addSession(session1);

        // Create attendees
        Attendee attendee1 = new Attendee("Dr. Abram", "abram@example.com", "A001");

        // Register attendees
        gafAI2025.registerAttendee(attendee1);

        // Attendee creates a schedule
        attendee1.createSchedule(session1);

        // Add attendee to the session
        session1.addAttendee(attendee1);

        // Display details
        System.out.println("Conference: " + gafAI2025.getConferenceName());
        System.out.println("\nSession Details:\n" + session1.getSessionDetails());

        // Generate certificates
        System.out.println("\nGenerating Certificates:");
        gafAI2025.generateCertificates();
    }
}

